package com.example.clinic.service.impl;

import com.example.clinic.dto.request.DoctorScheduleRequest;
import com.example.clinic.dto.response.DoctorScheduleResponse;
import com.example.clinic.dto.response.QueueStatusResponse;
import com.example.clinic.entity.Doctor;
import com.example.clinic.entity.DoctorSchedule;
import com.example.clinic.entity.TimeSlot;
import com.example.clinic.entity.enums.AuditActionType;
import com.example.clinic.entity.enums.ShiftType;
import com.example.clinic.entity.enums.SlotStatus;
import com.example.clinic.exception.DuplicateResourceException;
import com.example.clinic.exception.ResourceNotFoundException;
import com.example.clinic.repository.AppointmentRepository;
import com.example.clinic.repository.DoctorRepository;
import com.example.clinic.repository.DoctorScheduleRepository;
import com.example.clinic.repository.TimeSlotRepository;
import com.example.clinic.security.SecurityUtil;
import com.example.clinic.service.AuditLogService;
import com.example.clinic.service.DoctorScheduleService;
import com.example.clinic.mapper.DoctorScheduleMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DoctorScheduleServiceImpl implements DoctorScheduleService {

    private final DoctorScheduleRepository scheduleRepository;
    private final DoctorRepository doctorRepository;
    private final TimeSlotRepository timeSlotRepository;
    private final DoctorScheduleMapper scheduleMapper;
    private final AppointmentRepository appointmentRepository;
    private final AuditLogService auditLogService;

    // Tạo ca làm việc và tự động sinh các TimeSlot
    @Override
    @Transactional
    public DoctorScheduleResponse create(DoctorScheduleRequest request) {
        // Kiểm tra bác sĩ tồn tại không
        Doctor doctor = doctorRepository.findById(request.getDoctorId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Không tìm thấy bác sĩ với id: " + request.getDoctorId()));

        // Ownership: DOCTOR chỉ tạo schedule cho chính mình
        if (SecurityUtil.isDoctor()) {
            if (!doctor.getUser().getId().equals(SecurityUtil.getCurrentUserId())) {
                throw new AccessDeniedException(
                        "Bạn chỉ có thể tạo lịch làm việc cho chính mình");
            }
        }

        // Bác sĩ inactive không thể nhận bệnh nhân
        if (!doctor.isActive()) {
            throw new IllegalStateException(
                    "Không thể tạo lịch làm việc cho bác sĩ đang bị vô hiệu hóa");
        }

        // Ngày quá khứ không thể có slot khả dụng
        if (request.getWorkDate().isBefore(LocalDate.now())) {
            throw new IllegalStateException(
                    "Không thể tạo lịch làm việc cho ngày đã qua");
        }

        // Tránh tạo schedule không có slot nào vì toàn bộ giờ đã qua
        if (request.getWorkDate().isEqual(LocalDate.now())
                && !request.getEndTime().isAfter(LocalTime.now())) {

            throw new IllegalStateException(
                    "Không thể tạo lịch làm việc vì ca làm việc đã kết thúc");
        }

        // Kiểm tra bác sĩ đã có ca làm việc trong ngày đó chưa
        if (scheduleRepository.existsByDoctorIdAndWorkDate(
                request.getDoctorId(), request.getWorkDate())) {
            throw new DuplicateResourceException(
                    "Bác sĩ đã có ca làm việc vào ngày " + request.getWorkDate());
        }

        // Validate giờ bắt đầu phải trước giờ kết thúc
        if (!request.getStartTime().isBefore(request.getEndTime())) {
            throw new IllegalStateException("Giờ bắt đầu phải trước giờ kết thúc");
        }

        // Tạo schedule
        DoctorSchedule schedule = scheduleMapper.toEntity(request);
        schedule.setDoctor(doctor);
        DoctorSchedule savedSchedule = scheduleRepository.save(schedule);

        // Tự động sinh TimeSlot từ schedule
        List<TimeSlot> slots = generateTimeSlots(savedSchedule);

        // Không cho tạo schedule nếu không còn slot khả dụng
        if (slots.isEmpty()) {
            throw new IllegalStateException(
                    "Ca làm việc không tạo được slot khả dụng");
        }

        timeSlotRepository.saveAll(slots);

        // Load lại schedule với slots để trả về
        savedSchedule.setTimeSlots(slots);

        auditLogService.record(AuditActionType.SCHEDULE_MANUALLY_EDITED, "DOCTOR_SCHEDULE", savedSchedule.getId(),
                "Tạo ca làm việc thủ công cho bác sĩ " + doctor.getFullName()
                        + " ngày " + savedSchedule.getWorkDate(), null, null);
        return scheduleMapper.toResponseWithSlots(savedSchedule);
    }

    // ===== Sinh ca làm việc tự động từ đăng ký tuần đã duyệt =====
    // Khác với create(): không check ownership, không check "đã có ca trong ngày" theo kiểu cũ
    // (giờ unique theo doctorId+workDate+shiftType, không phải chỉ doctorId+workDate),
    // không check "ca đã kết thúc trong ngày hôm nay" (đăng ký luôn cho tuần trong tương lai).
    @Override
    @Transactional
    public DoctorScheduleResponse createFromApprovedRegistration(
            Long doctorId, LocalDate workDate, LocalTime startTime, LocalTime endTime, ShiftType shiftType) {

        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy bác sĩ với id: " + doctorId));

        if (scheduleRepository.existsByDoctorIdAndWorkDateAndShiftType(doctorId, workDate, shiftType)) {
            throw new DuplicateResourceException(
                    "Bác sĩ đã có ca " + shiftType + " vào ngày " + workDate);
        }
        if (!doctor.isActive()) {
            throw new IllegalStateException("Không thể tạo ca làm việc cho bác sĩ đang bị vô hiệu hóa");
        }

        DoctorSchedule schedule = DoctorSchedule.builder()
                .doctor(doctor)
                .workDate(workDate)
                .startTime(startTime)
                .endTime(endTime)
                .slotDurationMinutes(30)
                .active(true)
                .shiftType(shiftType)
                .note("Sinh tự động từ đăng ký lịch tuần")
                .build();

        DoctorSchedule savedSchedule = scheduleRepository.save(schedule);

        List<TimeSlot> slots = generateTimeSlots(savedSchedule);
        if (!slots.isEmpty()) {
            timeSlotRepository.saveAll(slots);
        }
        savedSchedule.setTimeSlots(slots);

        return scheduleMapper.toResponseWithSlots(savedSchedule);
    }


    // Lấy chi tiết ca làm việc kèm slot
    @Override
    @Transactional(readOnly = true)
    public DoctorScheduleResponse getById(Long id) {
        DoctorSchedule schedule = findByIdOrThrow(id);
        return scheduleMapper.toResponseWithSlots(schedule);
    }

    // ===== Trạng thái hàng chờ của 1 ca làm việc =====
    @Override
    @Transactional(readOnly = true)
    public QueueStatusResponse getQueueStatus(Long scheduleId) {
        DoctorSchedule schedule = findByIdOrThrow(scheduleId);

        long finishedCount = appointmentRepository.countFinishedInSchedule(scheduleId);
        int totalInShift = schedule.getTimeSlots().size();

        Integer currentServingNumber = finishedCount == 0 ? null : (int) finishedCount;
        // "Đang khám số X" = số slot đã xử lý xong + 1 (slot đang tới lượt), trừ khi đã xong hết ca
        if (finishedCount > 0 && finishedCount < totalInShift) {
            currentServingNumber = (int) finishedCount + 1;
        } else if (finishedCount >= totalInShift && totalInShift > 0) {
            currentServingNumber = totalInShift; // ca đã khám hết
        }

        boolean delayed = checkScheduleDelayed(schedule, finishedCount);

        return QueueStatusResponse.builder()
                .currentServingNumber(currentServingNumber)
                .totalInShift(totalInShift)
                .delayed(delayed)
                .delayMessage(delayed
                        ? "Ca khám đang trễ hơn dự kiến do các lượt khám trước phát sinh thêm thời gian."
                        : null)
                .build();
    }

    // Ca bị coi là trễ nếu: đã qua giờ bắt đầu của slot tiếp theo cần khám (dựa theo queueNumber),
    // nhưng slot đó vẫn chưa được xử lý xong (chưa COMPLETED/NO_SHOW)
    private boolean checkScheduleDelayed(DoctorSchedule schedule, long finishedCount) {
        return schedule.getTimeSlots().stream()
                .filter(slot -> slot.getQueueNumber() != null && slot.getQueueNumber() == finishedCount + 1)
                .anyMatch(slot -> {
                    LocalDateTime slotStart = LocalDateTime.of(schedule.getWorkDate(), slot.getStartTime());
                    return LocalDateTime.now().isAfter(slotStart);
                });
    }

    // Lấy lịch làm việc của bác sĩ trong khoảng ngày
    @Override
    @Transactional(readOnly = true)
    public List<DoctorScheduleResponse> getByDoctorAndDateRange(
            Long doctorId, LocalDate startDate, LocalDate endDate) {

        // Kiểm tra bác sĩ tồn tại
        if (!doctorRepository.existsById(doctorId)) {
            throw new ResourceNotFoundException("Không tìm thấy bác sĩ với id: " + doctorId);
        }

        return scheduleRepository.findByDoctorIdAndDateRange(doctorId, startDate, endDate)
                .stream()
                .map(scheduleMapper::toResponseWithSlots)
                .collect(Collectors.toList());
    }

    // Lấy lịch theo tuần (7 ngày từ weekStart)
    @Override
    @Transactional(readOnly = true)
    public List<DoctorScheduleResponse> getWeeklySchedule(Long doctorId, LocalDate weekStart) {
        LocalDate weekEnd = weekStart.plusDays(6);
        return getByDoctorAndDateRange(doctorId, weekStart, weekEnd);
    }

    // API công khai cho admin/bác sĩ: có kiểm tra
    @Override
    @Transactional
    public DoctorScheduleResponse deactivate(Long id) {
        DoctorSchedule schedule = findByIdOrThrow(id);

        boolean hasBooked = schedule.getTimeSlots().stream()
                .anyMatch(s -> s.getStatus() == SlotStatus.BOOKED);
        if (hasBooked) {
            throw new IllegalStateException(
                    "Ca làm việc đã có lịch hẹn. Hãy gửi đơn xin nghỉ để hệ thống hủy lịch và thông báo bệnh nhân");
        }
        DoctorScheduleResponse response = applyBlock(schedule);
        auditLogService.record(AuditActionType.SCHEDULE_MANUALLY_CANCELLED, "DOCTOR_SCHEDULE", id,
                "Vô hiệu hóa ca làm việc ngày " + schedule.getWorkDate()
                        + " của bác sĩ " + schedule.getDoctor().getFullName(), null, null);
        return response;
    }

    // Nội bộ cho DoctorBlockService: lịch hẹn đã được hủy trước đó nên không cần kiểm tra
    @Override
    @Transactional
    public DoctorScheduleResponse blockSchedule(Long id) {
        return applyBlock(findByIdOrThrow(id));
    }

    private DoctorScheduleResponse applyBlock(DoctorSchedule schedule) {
        schedule.setActive(false);
        schedule.getTimeSlots().forEach(slot -> {
            if (slot.getStatus() == SlotStatus.AVAILABLE) {
                slot.setStatus(SlotStatus.BLOCKED);
            }
        });
        timeSlotRepository.saveAll(schedule.getTimeSlots());
        return scheduleMapper.toResponseWithSlots(scheduleRepository.save(schedule));
    }

    // Xoá ca làm việc
    @Override
    @Transactional
    public void delete(Long id) {
        DoctorSchedule schedule = findByIdOrThrow(id);

        // Ownership: DOCTOR chỉ xóa schedule của chính mình
        if (SecurityUtil.isDoctor()) {
            if (!schedule.getDoctor().getUser().getId()
                    .equals(SecurityUtil.getCurrentUserId())) {
                throw new AccessDeniedException(
                        "Bạn chỉ có thể xóa lịch làm việc của chính mình");
            }
        }

        // Không cho xoá nếu đã có slot được đặt
        boolean hasBookedSlot = schedule.getTimeSlots().stream()
                .anyMatch(slot -> slot.getStatus() == SlotStatus.BOOKED);

        if (hasBookedSlot) {
            throw new IllegalStateException(
                    "Không thể xoá ca làm việc vì đã có lịch hẹn được đặt");
        }

        auditLogService.record(AuditActionType.SCHEDULE_MANUALLY_CANCELLED, "DOCTOR_SCHEDULE", id,
                "Xóa ca làm việc ngày " + schedule.getWorkDate()
                        + " của bác sĩ " + schedule.getDoctor().getFullName(), null, null);

        scheduleRepository.delete(schedule);
    }

    @Transactional
    @Override
    public DoctorScheduleResponse activate(Long id) {
        DoctorSchedule schedule = findByIdOrThrow(id);

        // Lịch quá khứ không có ý nghĩa, slot sẽ không đặt được
        if (schedule.getWorkDate().isBefore(LocalDate.now())) {
            throw new IllegalStateException(
                    "Không thể kích hoạt lịch làm việc của ngày đã qua");
        }

        schedule.setActive(true);

        // Mở lại tất cả slot đang BLOCKED
        schedule.getTimeSlots().forEach(slot -> {
            if (slot.getStatus() == SlotStatus.BLOCKED) {
                slot.setStatus(SlotStatus.AVAILABLE);
            }
        });
        timeSlotRepository.saveAll(schedule.getTimeSlots());

        DoctorSchedule saved = scheduleRepository.save(schedule);
        auditLogService.record(AuditActionType.SCHEDULE_MANUALLY_EDITED, "DOCTOR_SCHEDULE", id,
                "Kích hoạt lại ca làm việc ngày " + schedule.getWorkDate()
                        + " của bác sĩ " + schedule.getDoctor().getFullName(), null, null);
        return scheduleMapper.toResponseWithSlots(saved);
    }

    // ===== Private helper =====

    // Sinh danh sách TimeSlot từ DoctorSchedule
    // Nếu là lịch hôm nay thì bỏ qua các slot đã qua
    private List<TimeSlot> generateTimeSlots(DoctorSchedule schedule) {

        List<TimeSlot> slots = new ArrayList<>();

        LocalTime current = schedule.getStartTime();
        LocalTime endTime = schedule.getEndTime();
        int duration = schedule.getSlotDurationMinutes();

        LocalDateTime now = LocalDateTime.now();

        int position = 0; // Vị trí thứ mấy trong ca — tăng dần bất kể slot có bị bỏ qua hay không

        while (current.plusMinutes(duration).compareTo(endTime) <= 0) {

            position++;

            LocalTime slotEnd = current.plusMinutes(duration);

            LocalDateTime slotDateTime =
                    LocalDateTime.of(schedule.getWorkDate(), current);

            // Chỉ tạo slot còn trong tương lai
            if (slotDateTime.isAfter(now)) {

                TimeSlot slot = TimeSlot.builder()
                        .schedule(schedule)
                        .doctor(schedule.getDoctor())
                        .slotDate(schedule.getWorkDate())
                        .startTime(current)
                        .endTime(slotEnd)
                        .queueNumber(position)
                        .status(SlotStatus.AVAILABLE)
                        .build();

                slots.add(slot);
            }

            current = slotEnd;
        }

        return slots;
    }

    private DoctorSchedule findByIdOrThrow(Long id) {
        return scheduleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Không tìm thấy ca làm việc với id: " + id));
    }
}

package com.example.clinic.security;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;

import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity  // Cho phép dùng @PreAuthorize trên Controller/Service
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;
    private final UserDetailsService userDetailsService;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception {
        http
                // Tắt CSRF vì dùng JWT (stateless)
                .csrf(AbstractHttpConfigurer::disable)


                .cors(cors -> cors.configurationSource(request -> {
                    CorsConfiguration config = new CorsConfiguration();
                    config.setAllowedOrigins(List.of(
                            "http://localhost:5500",
                            "http://127.0.0.1:5500",
                            "http://localhost:5173",
                            "http://127.0.0.1:5173"
                    ));
                    config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
                    config.setAllowedHeaders(List.of("*"));
                    return config;
                }))

                // Cấu hình phân quyền từng API
                .authorizeHttpRequests(auth -> auth

                        // API công khai — không cần token
                        .requestMatchers(
                                "/api/v1/auth/login",
                                "/api/v1/auth/register",
                                "/api/v1/auth/google",
                                "/api/v1/auth/refresh",
                                "/api/v1/auth/forgot-password",
                                "/api/v1/auth/reset-password",
                                "/ws/**",          // handshake WebSocket; JWT được kiểm tra ở frame STOMP CONNECT
                                "/v3/api-docs/**",
                                "/swagger-ui/**",
                                "/swagger-ui.html",
                                "/api/v1/clinic"
                        ).permitAll()

                        // Gợi ý chuyên khoa theo triệu chứng: công khai (người chưa có tài khoản, token hết hạn vẫn dùng được).
                        // Chỉ khi gửi kèm patientId thì service mới đòi đăng nhập và kiểm tra quyền sở hữu hồ sơ.
                        .requestMatchers(HttpMethod.POST, "/api/v1/triage/next").permitAll()

                        .requestMatchers("/api/v1/auth/change-password").authenticated()
                        .requestMatchers("/api/v1/auth/logout").authenticated()

                        // API chỉ ADMIN được dùng
                        .requestMatchers("/api/v1/dashboard/**")
                        .hasRole("ADMIN")

                        // Mọi tài khoản đã đăng nhập xem được hồ sơ tài khoản của chính mình
                        .requestMatchers(HttpMethod.GET, "/api/v1/users/me").authenticated()

                        // API quản lý user chỉ dành cho ADMIN
                        .requestMatchers("/api/v1/users/**")
                        .hasRole("ADMIN")

                        // Bệnh nhân xem hồ sơ của chính mình
                        .requestMatchers(HttpMethod.GET, "/api/v1/patients/me")
                        .hasRole("PATIENT")

                        .requestMatchers(HttpMethod.POST, "/api/v1/patients/me")
                        .hasRole("PATIENT")

                        .requestMatchers(HttpMethod.PUT, "/api/v1/patients/me")
                        .hasRole("PATIENT")

                        // Quản lý hồ sơ người thân — bất kỳ ai đã đăng nhập đều được dùng (không giới hạn role)
                        .requestMatchers(HttpMethod.POST, "/api/v1/patients/managed")
                        .authenticated()

                        .requestMatchers(HttpMethod.GET, "/api/v1/patients/managed")
                        .authenticated()

                        // Admin xem hồ sơ bệnh nhân theo userId
                        .requestMatchers(HttpMethod.GET, "/api/v1/patients/user/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        // Danh sách / tìm kiếm toàn bộ bệnh nhân: bác sĩ không được dùng
                        .requestMatchers(HttpMethod.GET, "/api/v1/patients")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        // Xem chi tiết bệnh nhân
                        .requestMatchers(HttpMethod.GET, "/api/v1/patients/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST", "DOCTOR")

                        // Tạo / cập nhật / xóa bệnh nhân
                        .requestMatchers(HttpMethod.POST, "/api/v1/patients/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        .requestMatchers(HttpMethod.PUT, "/api/v1/patients/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        .requestMatchers(HttpMethod.DELETE, "/api/v1/patients/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        // Bác sĩ xem hồ sơ của chính mình
                        .requestMatchers(HttpMethod.GET, "/api/v1/doctors/me")
                        .hasRole("DOCTOR")

                        .requestMatchers(HttpMethod.GET, "/api/v1/doctors/user/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        // Xem thông tin bác sĩ
                        .requestMatchers(HttpMethod.GET, "/api/v1/doctors/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST", "DOCTOR", "PATIENT")

                        // CRUD bác sĩ
                        .requestMatchers(HttpMethod.POST, "/api/v1/doctors/**")
                        .hasRole("ADMIN")

                        // Kích hoạt / vô hiệu hoá bác sĩ: chỉ ADMIN (vô hiệu hoá sẽ hủy toàn bộ lịch hẹn tương lai)
                        .requestMatchers(HttpMethod.PUT, "/api/v1/doctors/*/active", "/api/v1/doctors/*/deactive")
                        .hasRole("ADMIN")

                        .requestMatchers(HttpMethod.PUT, "/api/v1/doctors/**")
                        .hasAnyRole("ADMIN", "DOCTOR")

                        .requestMatchers(HttpMethod.DELETE, "/api/v1/doctors/**")
                        .hasRole("ADMIN")

                        .requestMatchers(HttpMethod.GET, "/api/v1/specialties/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST", "DOCTOR", "PATIENT")

                        .requestMatchers("/api/v1/specialties/**")
                        .hasRole("ADMIN")

                        // Lịch hẹn: xác nhận chỉ lễ tân/admin; hoàn thành, không đến do bác sĩ/lễ tân/admin; tìm kiếm chung chỉ lễ tân/admin
                        .requestMatchers(HttpMethod.PUT, "/api/v1/appointments/*/confirm")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        .requestMatchers(HttpMethod.PUT, "/api/v1/appointments/*/complete", "/api/v1/appointments/*/no-show")
                        .hasAnyRole("ADMIN", "RECEPTIONIST", "DOCTOR")

                        .requestMatchers(HttpMethod.GET, "/api/v1/appointments/search")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        .requestMatchers(HttpMethod.GET, "/api/v1/appointments/patient/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST", "PATIENT")

                        .requestMatchers(HttpMethod.GET, "/api/v1/appointments/doctor/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST", "DOCTOR")

                        .requestMatchers("/api/v1/appointments/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST", "DOCTOR", "PATIENT")

                        // Xem lịch làm việc
                        .requestMatchers(HttpMethod.GET, "/api/v1/doctor-schedules/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST", "DOCTOR", "PATIENT")

                        // Tạo / bật / tắt / xóa ca: chỉ ADMIN. Bác sĩ đi qua đăng ký tuần và đơn nghỉ được duyệt
                        .requestMatchers("/api/v1/doctor-schedules/**")
                        .hasRole("ADMIN")

                        .requestMatchers(HttpMethod.POST, "/api/v1/work-schedule/registrations")
                        .hasRole("DOCTOR")

                        .requestMatchers(HttpMethod.GET, "/api/v1/work-schedule/registrations/me")
                        .hasRole("DOCTOR")

                        .requestMatchers(HttpMethod.GET, "/api/v1/work-schedule/registrations/pending")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        .requestMatchers(HttpMethod.GET, "/api/v1/work-schedule/registrations/doctor/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        .requestMatchers(HttpMethod.GET, "/api/v1/work-schedule/registrations/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST", "DOCTOR")

                        .requestMatchers(HttpMethod.PUT, "/api/v1/work-schedule/registrations/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        .requestMatchers("/api/v1/time-slots/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST", "DOCTOR", "PATIENT")

                        // ===== Đơn xin nghỉ (Doctor Leave Request) =====

                        .requestMatchers(HttpMethod.POST, "/api/v1/work-schedule/leave-requests")
                        .hasRole("DOCTOR")

                        .requestMatchers(HttpMethod.GET, "/api/v1/work-schedule/leave-requests/me")
                        .hasRole("DOCTOR")

                        .requestMatchers(HttpMethod.GET, "/api/v1/work-schedule/leave-requests/pending")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        .requestMatchers(HttpMethod.GET, "/api/v1/work-schedule/leave-requests/doctor/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        .requestMatchers(HttpMethod.GET, "/api/v1/work-schedule/leave-requests/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST", "DOCTOR")

                        .requestMatchers(HttpMethod.PUT, "/api/v1/work-schedule/leave-requests/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        // ===== Log nghiệp vụ lịch làm việc (chỉ Admin/Receptionist xem) =====
                        .requestMatchers(HttpMethod.GET, "/api/v1/work-schedule/audit-logs/**")
                        .hasAnyRole("ADMIN", "RECEPTIONIST")

                        .requestMatchers("/api/v1/audit-logs/**")
                        .hasRole("ADMIN")

                        .requestMatchers(HttpMethod.POST, "/api/v1/payments/*/refund")
                        .hasRole("ADMIN")

                        .requestMatchers(HttpMethod.GET, "/api/v1/payments/vnpay-ipn").permitAll()

                        .requestMatchers(HttpMethod.GET, "/api/v1/payments/**")
                        .hasAnyRole("PATIENT", "ADMIN", "RECEPTIONIST")

                        .requestMatchers(HttpMethod.POST, "/api/v1/payments")
                        .hasAnyRole("PATIENT", "ADMIN", "RECEPTIONIST")

                        .requestMatchers("/api/v1/notifications/**").authenticated()

                        // Tất cả request còn lại cần xác thực
                        .anyRequest().authenticated()
                )

                // Stateless — không dùng session
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                // Thêm authentication provider
                .authenticationProvider(authenticationProvider())

                // Thêm JWT filter trước UsernamePasswordAuthenticationFilter
                .addFilterBefore(jwtAuthFilter,
                        UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    // Mã hóa password bằng BCrypt
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // AuthenticationProvider: dùng DB để xác thực
    // Mới - Spring Boot 4.x
    @Bean
    public AuthenticationProvider authenticationProvider() {

        DaoAuthenticationProvider provider =
                new DaoAuthenticationProvider(userDetailsService);

        provider.setPasswordEncoder(passwordEncoder());

        return provider;
    }

    // AuthenticationManager: dùng trong AuthService để đăng nhập
    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}

package com.example.clinic.entity;

import com.example.clinic.entity.enums.AuthProvider;
import com.example.clinic.entity.enums.Role;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;



@Entity
@Table(name = "users",
        indexes = {
                @Index(name = "idx_users_role", columnList = "role")
        }
)
@Data
@ToString(exclude = {"patient", "doctor", "notifications"})
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User implements UserDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @Column(name = "username", nullable = false, unique = true, length = 100)
    private String username;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "email", nullable = false, unique = true, length = 255)
    private String email;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(name = "role", nullable = false)
    private Role role;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(nullable = false)
    private AuthProvider provider;

    // Reset password token
    @Column(name = "reset_token")
    private String resetToken;

    @Column(name = "reset_token_expiry")
    private LocalDateTime resetTokenExpiry;

    @Column(name = "enabled", nullable = false)
    @Builder.Default
    private boolean enabled = true;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // Tài khoản có bị khoá vì lý do bảo mật không (khác với "active" — do admin chủ động bật/tắt)
    @Column(name = "locked", nullable = false)
    @Builder.Default
    private boolean locked = false;

    // Thời điểm xoá mềm — null nghĩa là chưa xoá
    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    // ===== Relationships =====

    // 1 user có tối đa 1 hồ sơ bệnh nhân (nếu role = PATIENT)
    // cascade ALL: xoá user → xoá patient theo
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Patient patient;

    // 1 user có tối đa 1 hồ sơ bác sĩ (nếu role = DOCTOR)
    // cascade ALL: xoá user → xoá doctor theo
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Doctor doctor;

    // 1 user có nhiều thông báo
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Notification> notifications;

    // Tự động gán createdAt và updatedAt ngay trước khi INSERT vào database
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    // Tự động cập nhật updatedAt ngay trước khi UPDATE vào database
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // ===== UserDetails =====
    // Spring Security gọi các method dưới đây để kiểm tra quyền và trạng thái tài khoản

    // Trả về danh sách quyền của user, dùng để phân quyền trong Spring Security
    // VD: role = ADMIN → authority = "ROLE_ADMIN"
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + role.name()));
    }

    // Dùng email làm định danh đăng nhập thay vì username
    @Override
    public String getUsername() { return email; }

    // Tài khoản không bao giờ hết hạn
    @Override
    public boolean isAccountNonExpired() { return true; }

    // Mật khẩu không bao giờ hết hạn
    @Override
    public boolean isCredentialsNonExpired() { return true; }

    // Tài khoản bị khoá bảo mật → Spring Security từ chối đăng nhập
    @Override
    public boolean isAccountNonLocked() { return !locked; }

    // enabled=false (admin tắt) hoặc đã bị xoá mềm → không cho đăng nhập
    @Override
    public boolean isEnabled() { return enabled && deletedAt == null; }


}

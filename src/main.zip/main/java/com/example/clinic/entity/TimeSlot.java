package com.example.clinic.entity;

import com.example.clinic.entity.enums.SlotStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Entity
@Table(
        name = "time_slots",
        indexes = {
                @Index(name = "idx_slot_doctor_date",        columnList = "doctor_id, slot_date"),
                @Index(name = "idx_slot_doctor_date_status", columnList = "doctor_id, slot_date, status"),
                @Index(name = "idx_slot_schedule",           columnList = "schedule_id")
        },
        uniqueConstraints = {
                // Chống double-booking: 1 bác sĩ không thể có 2 slot cùng giờ cùng ngày
                @UniqueConstraint(
                        name = "uk_slot_doctor_date_time",
                        columnNames = {"doctor_id", "slot_date", "start_time"}
                )
        }
)
@Data
@ToString(exclude = {"schedule", "doctor", "appointments"})
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TimeSlot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "schedule_id", nullable = false)
    private DoctorSchedule schedule;

    // Lưu thêm doctor_id để query check lịch trống nhanh hơn
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doctor_id", nullable = false)
    private Doctor doctor;

    @Column(name = "slot_date", nullable = false)
    private LocalDate slotDate;

    @Column(name = "start_time", nullable = false)
    private LocalTime startTime;

    @Column(name = "end_time", nullable = false)
    private LocalTime endTime;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(name = "status", nullable = false, length = 20)
    @Builder.Default
    private SlotStatus status = SlotStatus.AVAILABLE;

    // Optimistic Locking: tránh 2 người cùng đặt 1 slot cùng lúc
    // Khi 2 transaction cùng update → người sau bị OptimisticLockException
    @Version
    @Column(name = "version")
    private Long version;

    // Số thứ tự trong ca làm việc — tính tại thời điểm sinh slot, không đổi dù appointment
    // gắn vào slot này có bị hủy/đặt lại bởi người khác. Dùng để hiển thị "Số thứ tự dự kiến"
    // trên phiếu khám điện tử, tương tự cách Medpro/BookingCare đang làm ngoài thực tế.
    @Column(name = "queue_number")
    private Integer queueNumber;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // ===== Relationships =====
    // ===== Relationships =====
    // 1 slot có thể có nhiều appointment theo lịch sử (VD: 1 cái CANCELLED, 1 cái đặt lại sau đó)
    // nhưng tại một thời điểm chỉ có tối đa 1 appointment đang active — đảm bảo ở tầng application
    @OneToMany(mappedBy = "timeSlot", fetch = FetchType.LAZY)
    private List<Appointment> appointments;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
